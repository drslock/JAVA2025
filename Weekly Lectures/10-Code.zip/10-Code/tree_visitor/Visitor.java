abstract class Visitor {
    abstract void visit(Fork t);
    abstract void visit(Leaf t);
}