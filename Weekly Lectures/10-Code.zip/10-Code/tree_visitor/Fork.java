class Fork extends Tree {
    Tree l;
    Tree r;

    Fork(Tree l, Tree r, String NodeName) {
        this.l = l;
        this.r = r;
        this.NodeName = NodeName;
    }

    @Override
    void accept(Visitor v) {
        v.visit(this);
    }
}
