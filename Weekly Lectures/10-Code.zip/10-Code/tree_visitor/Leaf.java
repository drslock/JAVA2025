class Leaf extends Tree {
    int value;

    Leaf(int value, String NodeName) {
        this.value = value;
        this.NodeName = NodeName;
    }

    @Override
    void accept(Visitor v) {
        v.visit(this);
    }
}
