public class Runner {
    public static void main(String [] args){
        Tree l1 = new Leaf(1, "L1");
        Tree l2 = new Leaf(2,"L2");
        Tree l3 = new Leaf(3, "L3");
        Tree n12 = new Fork(l1, l2, "N12");
        Tree tree = new Fork(n12, l3, "tree");
        SumVisitor visitor = new SumVisitor();
        tree.accept(visitor);
        System.out.println( "total: " + visitor.total);
    }
}
