class SumVisitor extends Visitor {
    int total;

    @Override
    void visit(Fork fork) {

        //LEFT BRANCH ------------
        System.out.println("Entering left branch of: " + fork.NodeName);
        fork.l.accept(this);
        System.out.println("Exiting left branch of: " + fork.NodeName);
        // -----------------------

        //RIGHT BRANCH ------------
        System.out.println("Entering right branch of: " + fork.NodeName);
        fork.r.accept(this);
        System.out.println("Exiting right branch of: " + fork.NodeName);
        // -----------------------
    }

    @Override
    void visit(Leaf leaf) {
        total += leaf.value;
        System.out.println(leaf.NodeName);
    }
}
