abstract public class Tree {
    public String NodeName;
    abstract void accept(Visitor v);
}
