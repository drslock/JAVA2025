Move the FinalCheckingOXOTests.java file into src/test/java/edu/uob
Then open the project in IntelliJ and run the test methods.
OR
Run `mvnw test` on the command line
(Maven should be able to find the test script if it is in the correct folder)
